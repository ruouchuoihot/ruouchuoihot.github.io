# The Card

# Discription

Holmes receives a breadcrumb from Dr. Nicole Vale - fragments from a string of cyber incidents across Cogwork-1. Each lead ends the same way: a digital calling card signed JM.

→ Đây là 1 challange thuần về SoC và CTI với việc cung cấp cho ta 3 file log và các platform về CTI

 ![](attachments/fc171b0c-eb98-425d-b4c9-4d1c299b888a.png " =487x237")

# Challange

## 1. Analyze the provided logs and identify what is the first User-Agent used by the attacker against Nicole Vale's honeypot. (string)

* Challange cung cấp 3 file logs là waf.log, application.log và access.log, để nắm đc thông tin `first User-Agent` , ta cần xem trong access.log để lấy info này và dựa theo trường time để lọc ra

  ![](attachments/5c72bf85-f114-4d5d-9666-bf6bfefe06eb.png " =1364x680")

  ```powershell
  Lilnunc/4A4D - SpecterEye
  ```

  \

## 2. It appears the threat actor deployed a web shell after bypassing the WAF. What is the file name? (filename.ext)

* Để tìm kiếm web shell đã đã được tạo ra sau khi bypass WAF, ta sẽ inves log waf
* Xuất hiện 1 event file \``.php` đc tạo ra với action là bypass

  ![](attachments/e35afcfa-1687-42a7-9f9a-1adcd5280ccd.png " =1287x665")

```powershell
temp_4A4D.php
```

## 3. The threat actor also managed to exfiltrate some data. What is the name of the database that was exfiltrated? (filename.ext)

* Cũng trong file log waf ta sẽ thấy tên DB

  ![](attachments/3beef3ce-c134-495a-926c-abc5ec1827aa.png " =1287x665")

```powershell
database_dump_4A4D.sql
```

## 4. During the attack, a seemingly meaningless string seems to be recurring. Which one is it? (string)

* Trong application log ta sẽ thấy 1 dãy 4A4D xuất hiện lặp đi lặp lại nhiều lần

  ![](attachments/c7c31ada-9062-4e06-88c2-45441a218986.png " =1575x466")

```powershell
4A4D
```

## 5. OmniYard-3 (formerly Scotland Yard) has granted you access to its CTI platform. Browse to the first IP:port address and count how many campaigns appear to be linked to the honeypot attack.

* Truy cập vào platform CTI của challenge cung cấp và filter theo campaigns sẽ filter được 8 cái

  ![](attachments/5d7b44ce-4d87-4c1a-bf0d-16527b446a95.png " =1852x914")
* Để ý Description của các campaigns ta sẽ thấy dòng JM signature (4A4D hex) tương tự với các string xuất hiện trong câu 4 và tổng cộng có 5 campaigns có signature này

  ![](attachments/efd7485c-274d-49c9-b202-97aa676bc4ce.png " =349x644")

```powershell
5
```

## 6. How many tools and malware in total are linked to the previously identified campaigns? (number)

* Từ câu 5 ta list được 5 campaigns như sau:
  * Operation Neural Storm
  * Quantum Heist
  * Civic Disruption
  * Bio-Breach
  * Transport Chaos


* Khi này ta sẽ vào tab Links của các Campaigns này và filter theo Category (Malware và Tool) để đếm số lượng

  ![](attachments/b1130c00-d2a3-4f35-aec8-d2395db21a48.png " =345x840")


* List tool và malware được sử dụng trong từng campains
  * Operation Neural Storm: 
    * Malware: NeuroStorm Implant
    * Tool: NeuroScan Pro
  * Quantum Heist:
    * Malware: QuantumCoin Stealer
    * Tool: QuantumKeyX
  * Civic Disruption:
    * Malware: CityWide Disruptor
    * Tool: CityMap Infiltrator
  * Bio-Breach:
    * Malware: BioMetric Falsifier
    * Tool: MedSys Probe
  * Transport Chaos:
    * Malware: Vehicle Chaos Engine

  => Số lượng tool và malware được dùng là 9

```powershell
9
```


## 7. It appears that the threat actor has always used the same malware in their campaigns. What is its SHA-256 hash? (sha-256 hash)

* Trong tab Links của Malware NeuroStorm, ta sẽ thấy 1 Indicator được link bên trong malware này

  ![](attachments/c73df9c5-16c1-49ca-829d-b11f9f0446d6.png " =369x452")
* Click vào indicator và chuyển qua tab details của indicator này ta sẽ thấy hash của malware

  ![](attachments/16bca68f-2957-413d-9141-fb689efaef8e.png " =369x449")

  \
  ```powershell
  7477c4f5e6d7c8b9a0f1e2d3c4b5a6f7e8d9c0b1a2f3e4d5c6b7a8f9e0d17477
  ```

## 8. Browse to the second IP:port address and use the CogWork Security Platform to look for the hash and locate the IP address to which the malware connects. (Credentials: nvale/CogworkBurning!)

* Access vào CogWork Security Platform của challange cung cấp

  ![](attachments/5baaaec4-3718-4aaf-8c9f-c8a83bf4383c.png " =1281x741")
* Search thông tin hash của câu 7 và kéo xuống phần Communications sẽ thấy được IP mà malware connect tới. Đây chính là các thông tin về C2 Server của malware

  ![](attachments/3ba0940f-1eb0-4781-938e-a1f581df8685.png " =1228x402")

```powershell
74.77.74.77
```

## 9.  What is the full path of the file that the malware created to ensure its persistence on systems? (/path/filename.ext)

* Click vào tab Details của malware và kéo xuống ta sẽ thấy phần File Operations

  ![](attachments/6252a01d-0e95-4a39-b4dc-986a3019e525.png " =728x169")

  ```powershell
  /opt/lilnunc/implant/4a4d_persistence.sh
  ```
* \

## 10. Finally, browse to the third IP:port address and use the CogNet Scanner Platform to discover additional details about the TA's infrastructure. How many open ports does the server have?

* Search IP của C2 server trên Platform scanner của challange ta sẽ thấy 11 port trên server

  ![](attachments/a6b0959e-41c3-4c08-934d-91578e4d11fd.png " =1300x876")

  ```powershell
  11
  ```

## 11. Which organization does the previously identified IP belong to? (string)

* Click vào Details của IP ta sẽ thấy organization

  ![](attachments/dd2dad21-4b19-48bc-a630-1c7b64f6e6c6.png " =1136x420")

  ```powershell
  SenseShield MSP
  ```

## 12. One of the exposed services displays a banner containing a cryptic message. What is it? (string)

* Click vào mục service để tìm kiếm thông tin về banner của các service
* Có 1 banner mang tính `cryptic` đúng với challange yêu cầu xuất hiện ở port 7477 với tên service version đều là unknown

  ![](attachments/db28787c-beac-4fe6-b188-aba3d46338ff.png " =1059x202")

  ```powershell
  He's a ghost I carry, not to haunt me, but to hold me together - NULLINC REVENGE
  ```


\

\